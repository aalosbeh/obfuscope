"""
Corpus health gate. Fails the build before any modelling work is spent.

Why this exists
---------------
A provenance corpus can look large and still carry almost no information. If a
generator emits identical output for every input in a class, that class collapses
to a single feature vector. Every classifier then separates it perfectly, every
metric saturates, and the reported accuracy measures the generator rather than
the attribution method. The failure is silent: row counts, class balance, and
grouped cross validation all look correct while the result is vacuous.

This gate turns that silent failure into a named, blocking one. It runs between
feature extraction and the model grid, so a degenerate corpus stops the pipeline
instead of producing a number that has to be retracted later.

The four checks
---------------
1. Distinct vector ratio per class. The share of a class's artifacts that have a
   feature vector no other artifact in that class shares. A class of 100
   artifacts with 1 distinct vector scores 0.01 and tells the model nothing about
   within class variation.

2. Constant features per class. A feature with zero variance across an entire
   class is not describing that class, it is naming it. A class where every
   feature is constant is a single point wearing a hundred coordinates.

3. Cross group duplicate clusters. Grouped cross validation only prevents
   leakage when the grouping variable actually separates the data. If one feature
   vector appears under two different group keys, the grouping constraint is
   satisfied while a feature identical row sits in both train and test. This is
   the leak the grouping was supposed to close.

4. Best single feature ceiling. Fit one decision stump per feature and take the
   best macro F1. If one scalar already reaches the headline accuracy, the
   corpus has an artifact dependent shortcut (file size is the usual one) and the
   multi feature model is not demonstrating what it claims to.

Thresholds are arguments, not constants, because the defensible value depends on
the transformation family. The defaults are deliberately strict: a corpus meant
to support an attribution claim should clear them comfortably.

Usage
-----
    python3 scripts/diversity_gate.py --features data/features.csv
    python3 scripts/diversity_gate.py --features data/features.csv \
        --label technique --min-distinct-ratio 0.80 --max-single-feature-f1 0.70

Exit status is 0 when every check passes and 1 when any check fails, so the
HTCondor DAG node holds the rest of the pipeline back on failure.
"""
from __future__ import annotations

import argparse
import json
import sys
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

LABEL_COLS = ["path", "cohort", "sample_id", "technique", "sub_technique", "malware_family"]


def feature_columns(df: pd.DataFrame) -> List[str]:
    cols = [c for c in df.columns if c not in LABEL_COLS]
    numeric = [c for c in cols if pd.api.types.is_numeric_dtype(df[c])]
    if not numeric:
        raise ValueError("no numeric feature columns found")
    return numeric


def _vector_keys(frame: pd.DataFrame, feats: Sequence[str]) -> pd.Series:
    """Hashable key per row so identical vectors compare equal.

    Rounded before hashing because two artifacts that differ only in floating
    point noise are not meaningfully distinct, and an unrounded hash would hide
    a degenerate class behind a trailing digit.
    """
    rounded = frame[list(feats)].astype("float64").round(9)
    return pd.Series(
        [hash(tuple(row)) for row in rounded.to_numpy()], index=frame.index
    )


# ---------------------------------------------------------------- check 1 and 2

def check_class_diversity(
    df: pd.DataFrame,
    feats: Sequence[str],
    label: str,
    min_distinct_ratio: float,
    max_constant_fraction: float,
) -> Tuple[bool, List[Dict], List[str]]:
    rows: List[Dict] = []
    failures: List[str] = []

    for cls, grp in df.groupby(label, sort=True):
        n = len(grp)
        keys = _vector_keys(grp, feats)
        n_distinct = int(keys.nunique())
        ratio = n_distinct / n if n else 0.0

        nunique_per_feat = grp[list(feats)].nunique(dropna=False)
        n_constant = int((nunique_per_feat <= 1).sum())
        const_fraction = n_constant / len(feats)

        rows.append(
            {
                "class": str(cls),
                "n": n,
                "distinct_vectors": n_distinct,
                "distinct_ratio": round(ratio, 4),
                "constant_features": n_constant,
                "constant_fraction": round(const_fraction, 4),
            }
        )

        if ratio < min_distinct_ratio:
            failures.append(
                f"class '{cls}': {n_distinct} distinct vectors in {n} artifacts "
                f"(ratio {ratio:.3f} below {min_distinct_ratio:.2f}). The generator "
                "is producing near identical output within this class, so the "
                "class is separable without any attribution signal."
            )
        if const_fraction > max_constant_fraction:
            failures.append(
                f"class '{cls}': {n_constant} of {len(feats)} features have zero "
                f"variance (fraction {const_fraction:.3f} above "
                f"{max_constant_fraction:.2f}). Those features identify the class "
                "rather than describe it."
            )

    return (not failures), rows, failures


# ---------------------------------------------------------------------- check 3

def check_cross_group_duplicates(
    df: pd.DataFrame,
    feats: Sequence[str],
    group: str,
    max_affected_fraction: float,
) -> Tuple[bool, Dict, List[str]]:
    keys = _vector_keys(df, feats)
    work = pd.DataFrame({"key": keys, "group": df[group].astype(str)})

    per_key = work.groupby("key")["group"].agg(["nunique", "size"])
    spanning = per_key[(per_key["nunique"] > 1) & (per_key["size"] > 1)]

    affected_rows = int(spanning["size"].sum())
    fraction = affected_rows / len(df) if len(df) else 0.0

    stats = {
        "group_column": group,
        "duplicate_clusters_spanning_groups": int(len(spanning)),
        "rows_in_those_clusters": affected_rows,
        "fraction_of_corpus": round(fraction, 4),
        "total_rows": int(len(df)),
        "distinct_vectors_overall": int(keys.nunique()),
    }

    failures: List[str] = []
    if fraction > max_affected_fraction:
        failures.append(
            f"{len(spanning)} duplicate feature vector clusters span more than one "
            f"'{group}', covering {affected_rows} rows ({fraction:.1%} of the "
            f"corpus, above {max_affected_fraction:.1%}). Grouping by '{group}' "
            "therefore does not stop feature identical rows appearing in both "
            "train and test, so the held out score is optimistic."
        )
    return (not failures), stats, failures


# ---------------------------------------------------------------------- check 4

def check_single_feature_ceiling(
    df: pd.DataFrame,
    feats: Sequence[str],
    label: str,
    group: str,
    max_f1: float,
    seed: int,
) -> Tuple[bool, Dict, List[str]]:
    """Best macro F1 reachable from one feature with a depth limited stump.

    Grouped splits are used so the ceiling is measured under the same protocol
    as the headline result. A single feature that clears the threshold is a
    shortcut, and reporting a multi feature model on top of it overstates what
    the feature set contributes.
    """
    from sklearn.model_selection import GroupShuffleSplit
    from sklearn.metrics import f1_score
    from sklearn.tree import DecisionTreeClassifier

    y = df[label].astype(str).to_numpy()
    groups = df[group].astype(str).to_numpy()

    n_classes = len(np.unique(y))
    if n_classes < 2:
        return True, {"skipped": "fewer than two classes"}, []
    if len(np.unique(groups)) < 2:
        return True, {"skipped": f"fewer than two '{group}' values"}, []

    splitter = GroupShuffleSplit(n_splits=3, test_size=0.3, random_state=seed)
    splits = list(splitter.split(np.zeros(len(df)), y, groups))

    scores: Dict[str, float] = {}
    for feat in feats:
        x = df[[feat]].astype("float64").fillna(0.0).to_numpy()
        fold_scores = []
        for tr, te in splits:
            if len(np.unique(y[tr])) < 2:
                continue
            clf = DecisionTreeClassifier(
                max_depth=min(8, n_classes + 2), random_state=seed
            )
            clf.fit(x[tr], y[tr])
            fold_scores.append(
                f1_score(y[te], clf.predict(x[te]), average="macro", zero_division=0)
            )
        if fold_scores:
            scores[feat] = float(np.mean(fold_scores))

    if not scores:
        return True, {"skipped": "no evaluable splits"}, []

    ranked = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)
    best_feat, best = ranked[0]

    stats = {
        "best_feature": best_feat,
        "best_macro_f1": round(best, 4),
        "top_five": [{"feature": f, "macro_f1": round(s, 4)} for f, s in ranked[:5]],
        "threshold": max_f1,
    }

    failures: List[str] = []
    if best > max_f1:
        failures.append(
            f"single feature '{best_feat}' reaches macro F1 {best:.3f} on its own "
            f"(above {max_f1:.2f}). One scalar is carrying the attribution result, "
            "so the corpus has an artifact dependent shortcut rather than a "
            "transformation signature."
        )
    return (not failures), stats, failures


# ----------------------------------------------------------------------- report

def _table(rows: Sequence[Dict], cols: Sequence[str]) -> str:
    header = [c for c in cols]
    body = [[str(r.get(c, "")) for c in cols] for r in rows]
    widths = [max(len(header[i]), *(len(b[i]) for b in body)) if body else len(header[i])
              for i in range(len(header))]
    out = ["  ".join(h.ljust(widths[i]) for i, h in enumerate(header)),
           "  ".join("-" * w for w in widths)]
    for b in body:
        out.append("  ".join(b[i].ljust(widths[i]) for i in range(len(header))))
    return "\n".join(out)


def run(
    features_path: str,
    label: str,
    group: str,
    min_distinct_ratio: float,
    max_constant_fraction: float,
    max_affected_fraction: float,
    max_single_feature_f1: float,
    seed: int,
    report_path: Optional[str],
    skip_single_feature: bool,
) -> int:
    df = pd.read_csv(features_path)
    for col in (label, group):
        if col not in df.columns:
            raise ValueError(f"column '{col}' not in {features_path}")
    feats = feature_columns(df)

    print(f"corpus    {features_path}")
    print(f"rows      {len(df)}")
    print(f"features  {len(feats)}")
    print(f"label     {label}  ({df[label].nunique()} classes)")
    print(f"group     {group}  ({df[group].nunique()} groups)")
    print()

    all_failures: List[str] = []
    report: Dict = {"features_path": features_path, "label": label, "group": group}

    ok1, class_rows, f1_fail = check_class_diversity(
        df, feats, label, min_distinct_ratio, max_constant_fraction
    )
    print("CHECK 1 and 2  per class diversity and constant features")
    print(_table(class_rows, ["class", "n", "distinct_vectors", "distinct_ratio",
                              "constant_features", "constant_fraction"]))
    print()
    report["per_class"] = class_rows
    all_failures += f1_fail

    ok3, dup_stats, f3_fail = check_cross_group_duplicates(
        df, feats, group, max_affected_fraction
    )
    print("CHECK 3  duplicate feature vectors spanning groups")
    for k, v in dup_stats.items():
        print(f"  {k:38s} {v}")
    print()
    report["cross_group_duplicates"] = dup_stats
    all_failures += f3_fail

    if skip_single_feature:
        print("CHECK 4  skipped by request")
        print()
        report["single_feature"] = {"skipped": "by request"}
    else:
        ok4, sf_stats, f4_fail = check_single_feature_ceiling(
            df, feats, label, group, max_single_feature_f1, seed
        )
        print("CHECK 4  best single feature ceiling")
        for k, v in sf_stats.items():
            if k == "top_five":
                print("  top_five")
                for item in v:
                    print(f"    {item['feature']:30s} {item['macro_f1']}")
            else:
                print(f"  {k:38s} {v}")
        print()
        report["single_feature"] = sf_stats
        all_failures += f4_fail

    report["failures"] = all_failures
    report["passed"] = not all_failures

    if report_path:
        with open(report_path, "w") as fh:
            json.dump(report, fh, indent=2)
        print(f"report written to {report_path}")
        print()

    if all_failures:
        print("GATE FAILED")
        for i, msg in enumerate(all_failures, 1):
            print(f"  {i}. {msg}")
        print()
        print("The corpus does not support an attribution claim in its current "
              "state. Increase generator variation, widen the input programs, or "
              "drop the degenerate classes, then rebuild.")
        return 1

    print("GATE PASSED  every class carries within class variation, no duplicate "
          "vector spans a group, and no single feature reaches the threshold")
    return 0


def main(argv: Optional[Sequence[str]] = None) -> int:
    ap = argparse.ArgumentParser(
        description="Fail a corpus that cannot support an attribution claim."
    )
    ap.add_argument("--features", required=True, help="feature table CSV")
    ap.add_argument("--label", default="technique",
                    help="label column under test (default technique)")
    ap.add_argument("--group", default="sample_id",
                    help="grouping column whose leakage is checked (default sample_id)")
    ap.add_argument("--min-distinct-ratio", type=float, default=0.80,
                    help="minimum distinct feature vectors per class artifact")
    ap.add_argument("--max-constant-fraction", type=float, default=0.50,
                    help="maximum fraction of features allowed zero variance in a class")
    ap.add_argument("--max-cross-group-fraction", type=float, default=0.05,
                    help="maximum corpus fraction in duplicate clusters spanning groups")
    ap.add_argument("--max-single-feature-f1", type=float, default=0.70,
                    help="maximum macro F1 any one feature may reach alone")
    ap.add_argument("--skip-single-feature", action="store_true",
                    help="skip check 4, which is the slowest")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--report", default=None, help="write a JSON report here")
    args = ap.parse_args(argv)

    return run(
        features_path=args.features,
        label=args.label,
        group=args.group,
        min_distinct_ratio=args.min_distinct_ratio,
        max_constant_fraction=args.max_constant_fraction,
        max_affected_fraction=args.max_cross_group_fraction,
        max_single_feature_f1=args.max_single_feature_f1,
        seed=args.seed,
        report_path=args.report,
        skip_single_feature=args.skip_single_feature,
    )


if __name__ == "__main__":
    sys.exit(main())
