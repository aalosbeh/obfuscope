"""
Light, dependency-free configuration shared across the package.

This module deliberately imports nothing heavier than :mod:`obfuscope.features`
(itself standard-library only), so that grid enumeration and manifest generation
run on a bare HTCondor access point that has no numpy/scikit-learn installed.
The scientific stack is only needed inside the execution-point container, not to
build the list of jobs.
"""
from __future__ import annotations

from typing import Dict, List

from .features import FEATURE_FAMILIES

# Named feature-set presets for the ablation axis.
FEATURE_SETS: Dict[str, List[str]] = {
    "all": list(FEATURE_FAMILIES.keys()),
    "lexical_only": ["lexical"],
    "no_obfuscation": [k for k in FEATURE_FAMILIES if k != "obfuscation"],
    "structural": ["lexical", "control_flow", "operator", "entropy"],
    "semantic": ["api", "obfuscation", "literal"],
}

# Mapping from task name to the dataframe column holding its target label.
TASK_LABEL: Dict[str, str] = {
    "provenance": "technique",
    "sub_provenance": "sub_technique",
}

# Canonical classifier names. Kept here (rather than derived from the sklearn
# registry) so it is importable without sklearn; models.py asserts consistency.
MODEL_NAMES: List[str] = [
    "extra_trees", "hist_gbdt", "knn", "logreg", "mlp", "random_forest", "svm_rbf",
]
